—————————CheckPoint3———————————————————————————————————————————————————————————-
——————————————————Group2—————————————————————————————————————————————

1. NaiveBayes Algorithm is implemneted to detect spam comments from Youtube. 
2. A third party library opencsv is used to read csv files as it take care of all the commas or “” in the file. 
3. Constraint —> To run the file use Eclipse IDE and run the spamDetection.java class from it.  
 
******************************************************************************************
The sample output by running the file is 

No. of Correct Comments :18.0
Incorrectly classified documents : [[1, 0, 1, 0, 1]]
No. of Incorrect Comments :5.0
Correctly classified comments: 18 out of 23 Real Time Data ---> for Youtube Video PSY 
Accuracy of the classifier : 0.782608695652174
