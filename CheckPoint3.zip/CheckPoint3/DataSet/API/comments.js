
//api formation
var api = 'https://www.googleapis.com/youtube/v3/commentThreads?videoId=';
var apiKey = '&key=AIzaSyCfMV7-URgcG23QBn5lwgkU7SiHnCFkBxs';
var parts = '&part=snippet,replies';
var maxResults = '&maxResults=100';
var nextPagetoken = '&pageToken=QURTSl9pME5BQ2MtRGJyaV82emZ1SW41WkFodXR5UWlNTkEzX29MNk50SVpVYlFjcnh2c0pXNWZYZGZQdXlIX2MtMzRnUE5Ia0FpTmliMEcwS0xscHhxN1VJMmtxSHpUVkhjczVFWDZtRV9KR3FLOXdVSldSSXAzNGJ1LVhuMmNVdmJiZWpxZ1cweVAtSmJqb0E=';


// array to store comments
var saveComments =[];



function setup() {
  noCanvas();
  
  var button = select('#submit');
  button.mousePressed(AskComments);

  

  input = select('#videoId');
}

function AskComments() {
  
  var url = api + input.value() + apiKey + parts + maxResults+ nextPagetoken; 
  loadJSON(url, gotData);
}


function gotData(data) {
  var comments = data.items;
  

    for(var i =0; i < comments.length; i++) {
      createElement('h1',comments[i].snippet.topLevelComment.snippet.authorDisplayName);
      createP(comments[i].snippet.topLevelComment.snippet.textDisplay);
      createP(comments[i].snippet.topLevelComment.snippet.publishedAt);

      var myCommentsObject = {
                              Comment: comments[i].snippet.topLevelComment.snippet.textOriginal.replace(/,/g, ''), // remove commas to avoid errors
                              Author: comments[i].snippet.topLevelComment.snippet.authorDisplayName,
                              Published: comments[i].snippet.topLevelComment.snippet.publishedAt
      };
      saveComments.push(myCommentsObject);          
    }

download();
}

//for converting JSON to csv file and saving it. Take from codepen
function convertToCSV(objArray) {
    var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
    var str = '';

    for (var i = 0; i < array.length; i++) {
        var line = '';
        for (var index in array[i]) {
            if (line != '') line += ','

            line += array[i][index];
        }

        str += line + '\r\n';
    }

    return str;
}

function exportCSVFile(headers, items, fileTitle) {
    if (headers) {
        items.unshift(headers);
    }

    // Convert Object to JSON
    var jsonObject = JSON.stringify(items);

    var csv = this.convertToCSV(jsonObject);

    var exportedFilenmae = fileTitle + '.csv' || 'export.csv';

    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    if (navigator.msSaveBlob) { // IE 10+
        navigator.msSaveBlob(blob, exportedFilenmae);
    } else {
        var link = document.createElement("a");
        if (link.download !== undefined) { // feature detection
            // Browsers that support HTML5 download attribute
            var url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", exportedFilenmae);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }
}

function download(){
  var headers = {
    Comment: 'Youtube comment'.replace(/,/g, ''), // remove commas to avoid errors
    Author: "Name",
    Published: "Time"
};


var commentsFormatted = [];

  // format the data
  saveComments.forEach((item) => {
      commentsFormatted.push({
          Comment: item.Comment.replace(/\n/g, ''), // remove commas to avoid errors,
          Author: item.Author,
          Published: item.Published
      });
  });
console.log(commentsFormatted);


var fileTitle = 'Comments'; // or 'my-unique-title'

exportCSVFile(headers, commentsFormatted, fileTitle); // call the exportCSVFile() function to process the JSON and trigger the download

   
}
   
    //println(comments);

 // println(data.items[0].snippet.videoId);

 // println(data.items[0].snippet.topLevelComment.kind);



