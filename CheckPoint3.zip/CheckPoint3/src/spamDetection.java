import java.io.*;
import java.util.*;
import java.util.regex.*;
import com.opencsv.CSVReader;

public class spamDetection {
	String[] trainingDocs;
	int[] trainingLabels;
	int numClasses;
	int[] classCounts; //number of docs per class
	String[] classStrings; //concatenated string for a given class
	int[] classTokenCounts; //total number of tokens per class
	HashMap<Integer,String[]> classTokens;
	HashMap<String,Double>[] condProb;
	HashSet<String> vocabulary; //entire vocabuary
	ArrayList<String> stopList=createStopWordList("src/stopwords.txt");
	ArrayList<String> foullang=createFoulList("src/foul.txt");

	
	String[] tokensArray;
	StringBuffer stringRead = new StringBuffer();//reading the documents
	public spamDetection(String[] docs, int[] labels, int numC)
	{
		trainingDocs = docs;
		trainingLabels = labels;
		numClasses = numC;
		classCounts = new int[numClasses];
		classStrings = new String[numClasses];
		classTokenCounts = new int[numClasses];
		condProb = new HashMap[numClasses];
		vocabulary = new HashSet<String>();
		//System.out.println(Collections.singletonList(stopList));
		// smaller than 2
		for(int i=0;i<numClasses;i++){
			classStrings[i] = "";
			condProb[i] = new HashMap<String,Double>();
		}
		
		for(int i=0;i<trainingLabels.length;i++){
			classCounts[trainingLabels[i]]++;
			classStrings[trainingLabels[i]] += (trainingDocs[i] + " ");
		}
		
		for(int i=0;i<numClasses;i++){
			String[] tokens = classStrings[i].split(" ");		
			String[] tokensArray = preProcess(tokens);
			//System.out.println(Arrays.toString(tokensArray));
			
			classTokens=new HashMap<Integer,String[]>(); // to store tokens for each class
			classTokens.put(i,tokensArray);
			classTokenCounts[i] = tokensArray.length;
			  
			  //collecting the counts
			  for(String token:classTokens.get(i)) {
				  vocabulary.add(token);
				  if(condProb[i].containsKey(token)){
					  double count = condProb[i].get(token);
					  condProb[i].put(token, count+1);
				  }
				  else
					  condProb[i].put(token, 1.0);
			  }			  
			//System.out.println(i+" count "+Arrays.asList(condProb[i]));
		}	  
		
		//computing the class conditional probability
		for(int j=0;j<numClasses;j++){
				  Iterator<Map.Entry<String, Double>> iterator = condProb[j].entrySet().iterator();
				  int vSize = vocabulary.size();
				  while(iterator.hasNext())
				  {
					  Map.Entry<String, Double> entry = iterator.next();
					  String token = entry.getKey();
					  Double count = entry.getValue();
					  count = (count+1)/(classTokenCounts[j]+vSize);

					  condProb[j].put(token, count);
				  }
				//System.out.println("condProb "+ j +" "+condProb[j]);
		}//numClasses loop
		//System.out.println("Now "+Arrays.asList(condProb));
	}//constructor end
	
	public ArrayList<String> createStopWordList(String fileName){
		try {
			File file = new File(fileName);
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line = null;
			stopList = new ArrayList<String>();
			while((line = reader.readLine())!=null){
				stopList.add(line);
			}
			stopList.add("a");
			reader.close();
		}
		catch (IOException e){
			e.printStackTrace();
		}
		return stopList;
	}
	public ArrayList<String> createFoulList(String fileName){
		try {
			File file = new File(fileName);
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line = null;
			foullang = new ArrayList<String>();
			while((line = reader.readLine())!=null){
				foullang.add(line);
			}
			reader.close();
		}
		catch (IOException e){
			e.printStackTrace();
		}
		return foullang;
	}
	// preprocess train and test data
	public String[] preProcess(String[] doc){
		String[] tokens = doc;
		ArrayList<String> newTokens = new ArrayList<String>();
		Stemmer st = new Stemmer();
		/*Pattern matching through
		 * Matcher object 
		 */
		Matcher urL1 = null; // url type1 matching
		Matcher urL2 = null; 
		Matcher urL3 = null;// url type3 matching
		Matcher urL4 = null;
		Matcher whiteSp = null; //punctuation marks matching
		Matcher emo1 = null; // emoji type 1 matching
		Matcher emo2 = null; // emoji type 2 matching
		Matcher wrdPunct = null;
		
		Pattern url1 = Pattern.compile("^((http[s]?|ftp):\\/)?\\/?([^:\\/\\s]+)((\\/\\w+)*\\/)([\\w\\-\\.]+[^#?\\s]+)(.*)?(#[\\w\\-]+)?$"); // for url link
		Pattern url2 = Pattern.compile("https?://[^\\s<>\"]+|www\\.[^\\s<>\"]+\\'");
		Pattern url3 = Pattern.compile("[\\/]?(watch)[\\?v]{1,}=[0-9a-zA-Z]{1,}");
		Pattern url4 = Pattern.compile("(\\w+[ !*#$@^&*():.,]{0,})+(http[s])?[:\\/]{1,2}(www)?.(\\w)+[:\\/.]{1,}\\w+.\\w+(\\/\\w+)((\\w+[ !*#$@^&*():.,]{0,})+)?");
		Pattern emoji1 = Pattern.compile("^[>:xD;8<B'=\\^\\|%Oo@75\\\\\\/\\/}0><\\-(]{1,}[-_o]?[\\)\\[\\]3*80\\(Pp@cdDB\\\\\\|@OoÞb\\/$X#J<>:\\-\\^]{1,}");
		Pattern emoji2 = Pattern.compile("[^\u1F600-\\uE007F]");
		Pattern whiteSpace = Pattern.compile(" "); // for punctuation mark in the comments
		Pattern wordPunct = Pattern.compile("[\\W]{0,}(\\w+)[\\W]{0,}");
		
		try {
			for (int k = 0; k < tokens.length; k++) 
			{ // stop word removal
				
				if (!stopList.contains(tokens[k].toLowerCase())) {
					//System.out.println(tokens[k]); //printing each comment
					urL1 = url1.matcher(tokens[k].toLowerCase()); // url matching
					urL2 = url2.matcher(tokens[k].toLowerCase());
					urL3 = url3.matcher(tokens[k].toLowerCase());
					urL4 = url4.matcher(tokens[k].toLowerCase());
					emo1 = emoji1.matcher(tokens[k].toLowerCase()); // emoji matching
					emo2 = emoji2.matcher(tokens[k].toLowerCase());
					whiteSp = whiteSpace.matcher(tokens[k].toLowerCase()); // punctuation matching
					wrdPunct = wordPunct.matcher(tokens[k].toLowerCase());

					if (urL1.matches() || urL2.matches() || urL3.matches() || urL4.matches()) { // if any url found
						// replace it with [url]
						newTokens.add("[url]");
					}
					else if (emo1.matches() || emo2.matches()) { // else if emoji found replace with [emojis]
						newTokens.add("[emojis]");
					}
					else if (foullang.contains(tokens[k].toLowerCase()) ){
						newTokens.add("[foul]");
					} 
					else if (whiteSp.matches()) {
						newTokens.add("[whiteSPACE]");
					} else if (wrdPunct.matches()) {
						// String term= tokens[k].replaceAll("[.,?!:\\-(;$%\")']{1,}","").toLowerCase();
						String term = tokens[k].replaceAll("\\p{P}", "").toLowerCase();
						st.add(term.toCharArray(), term.length());
						st.stem();
						// System.out.println(st.toString());
						newTokens.add(st.toString());
					} else {
						st.add(tokens[k].toCharArray(), tokens[k].length()); // stemming
						st.stem();
						newTokens.add(st.toString().toLowerCase());
					}
					// System.out.print(newTokens);
				} // end if not stop word
				else {
					continue;
				}
			}
		}
          catch (Exception e) {
			e.printStackTrace();
		}
		
		String[] tokensArray = newTokens.toArray(new String[newTokens.size()]);
 		 
		 return tokensArray;
	}
	
	public int classify(String doc){
		int label = 0;
		int vSize = vocabulary.size();

		double[] score = new double[numClasses];
		for(int i=0;i<score.length;i++){
			score[i] = Math.log(classCounts[i]*1.0/trainingDocs.length);
		}
		
		String[] tokens = doc.split(" ");
		for(int i=0;i<numClasses;i++){
			for(String token: tokens){
				if(condProb[i].containsKey(token))
					score[i] += Math.log(condProb[i].get(token));
				else
					score[i] += Math.log(1.0/(classTokenCounts[i]+vSize));
			}
		}
		double maxScore = score[0];
		for(int i=0;i<score.length;i++){
			if(score[i]>maxScore)
				label = i;
		}
		return label;
	}
	
	//  finding accuracy of the test documents
	public double classifyAll(String[] testDoc, int[] testLabels) {
		double accuracy = 0.0;
		try {		
	//	File filesNames = new File(testDataFolder);
		ArrayList<Integer> correct = new ArrayList<Integer>();
		ArrayList<Integer> incorrect = new ArrayList<Integer>();
		ArrayList<String> trainingDocs1 = new ArrayList<String>();
		ArrayList<String> testingDocs = new ArrayList<String>();
		//String[] files = filesNames.list();
		// System.out.println(files);

		for (int i = 0; i < testDoc.length; i++) {			
			    String testingDoc="";
			    String[] test= preProcess(testDoc[i].split(" "));	
			   // System.out.println(Arrays.toString(test));
				for (int j=0;j<test.length;j++) {
					testingDoc+=test[j]+" ";
				}
				int label = classify(testingDoc);
				//System.out.println(label +" "+i);
				if (label == testLabels[i]) {// the label has to match the position of the file in the file array
					correct.add(label);
				} else {
					//System.out.println("Incorrect classified: " + testingDoc);
					incorrect.add(label);
				}
				stringRead.setLength(0);
		}
		//System.out.println(Collections.singletonList(correct)+"\n"+Collections.singletonList(incorrect));
		
		double total = correct.size() + incorrect.size();
		double correctSize = correct.size();
		double incorrectSize = incorrect.size();
		accuracy = correctSize / total;
		System.out.println("No. of Correct Comments :" + correctSize);
		System.out.println("Incorrectly classified documents : " + Collections.singletonList(incorrect));
		System.out.println("No. of Incorrect Comments :" + incorrectSize);
		System.out.println("Correctly classified comments: " + ((int) correctSize) + " out of " + ((int) total) + " Real Time Data --->" +" for Youtube Video PSY ");
		System.out.println("Accuracy of the classifier : " + accuracy);
		return accuracy;
	}
		catch (Exception e) {
			e.printStackTrace();
			return accuracy;
		}
		
	}

	public static void main(String[] args) throws Exception{
		int numClass = 2;
		String trainData = new File("").getAbsolutePath().concat("/src/Data/train/");
		String testData = new File("").getAbsolutePath().concat("/src/Data/test/");
		
		CSVParser content = new CSVParser(); //train, test	
		content.processCSVData(trainData);
		String[] trainDocs = content.commentsArray;
		int[] trainLabels = content.labelsArray;

		
		spamDetection spamD = new spamDetection(trainDocs, trainLabels, numClass);	
		
		//System.out.println("printing test data length");
		CSVParser testcontent = new CSVParser();
		testcontent.processCSVData(testData);			
		String[] testDocs = new String[testcontent.commentsArray.length];
		testDocs=testcontent.commentsArray;
		int[] testLabels = testcontent.labelsArray;
		//System.out.println(testLabels);
        spamD.classifyAll(testDocs, testLabels);
	}
}
