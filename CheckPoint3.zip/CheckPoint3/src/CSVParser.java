import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import com.opencsv.CSVReader;

public class CSVParser {
	String[] commentsArray;
	int[] labelsArray;
	//String[] testCommentsArray;
 
	/*using CSV reader to read data from csv files
	 * @param folders containing the files
	 */
	public void processCSVData(String folderName) throws Exception {
		ArrayList < String > comments = new ArrayList < String>(); // comments from csv files
		ArrayList < Integer > labels = new ArrayList < Integer>();
		try {
				File path = new File(folderName);
				File[] files = path.listFiles();
  // class types valid = 1 , invalid = 0
				//ArrayList < String > testComments = new ArrayList < >();
				for (int i = 0; i < files.length; i++) {
					if (files[i].isFile()) { //this line weeds out other directories/folders
						//System.out.println(files[i]); //checking the file 
						CSVReader reader = new CSVReader(new FileReader(files[i]), ',', '"', 1);	                 
						//Read CSV line by line and use the string array
						String[] nextLine;
						while ((nextLine = reader.readNext()) != null) {
							if (nextLine != null) {
								comments.add(nextLine[3]);
							    //System.out.println(Arrays.toString(nextLine));
								labels.add(Integer.parseInt(nextLine[4]));
								
							}	
						}
						reader.close();
					}
				}	
		  }catch(Exception e) {
			  System.out.println(e.getMessage());
		  }
		
		//Transferring the comments from Arraylist to array
		this.commentsArray = new String[comments.size()];
		for (int j = 0; j < comments.size(); j++) {
			this.commentsArray[j] = comments.get(j);
		}
	//	System.out.println(Collections.singletonList(labels));
		//Transferring the labels from Arraylist to array
		if (labels.size()>0) {
			this.labelsArray = new int[labels.size()];
			for (int j = 0; j < labels.size(); j++) {
				this.labelsArray[j] = labels.get(j).intValue();	
			}
			
		}
		
	}

}